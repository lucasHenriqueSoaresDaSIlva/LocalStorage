// Lucas Henrique DEV2B


function carregarLocalStorage() {
  const nome = localStorage.getItem('nome') || '';
  const email = localStorage.getItem('email') || '';
  const mensagem = localStorage.getItem('mensagem') || '';
  document.getElementById('nome').value = nome;
  document.getElementById('email').value = email;
  document.getElementById('mensagem').value = mensagem;
}

// Salvar dados do formulário no localStorage enquanto digita
const inputs = document.querySelectorAll('#contatoForm input, #contatoForm textarea');
inputs.forEach(input => {
  input.addEventListener('input', () => {
    localStorage.setItem(input.id, input.value);
  });
});

// Função para salvar dados no sessionStorage como JSON
document.getElementById('enviar').addEventListener('click', () => {
  const dados = {
    nome: document.getElementById('nome').value,
    email: document.getElementById('email').value,
    mensagem: document.getElementById('mensagem').value
  };
  sessionStorage.setItem('dadosContato', JSON.stringify(dados));
  exibirDados();
  alert('Dados enviados e salvos no sessionStorage!');
});

// Função para exibir dados do sessionStorage convertidos de JSON
function exibirDados() {
  const dados = sessionStorage.getItem('dadosContato');
  if(dados) {
    const objeto = JSON.parse(dados);
    document.getElementById('dadosSalvos').textContent = JSON.stringify(objeto, null, 2);
  }
}

// Detectar alterações no localStorage em tempo real entre abas
window.addEventListener('storage', (event) => {
  if(event.key === 'nome' || event.key === 'email' || event.key === 'mensagem') {
    carregarLocalStorage();
    console.log('Alteração detectada em outra aba:', event.key, event.newValue);
  }
});

// Inicialização
carregarLocalStorage();
exibirDados();
